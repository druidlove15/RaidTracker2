<?php
$rt=true;
$frames=0;
$rt_menu='guild';
$incmain='rt-tos.php';
$incside='../rt-side-blank.php';
$title='Guild list';
include "../include/rti-main.php";
?>
