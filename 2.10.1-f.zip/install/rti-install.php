<?php
echo $_page['main'];
?>
