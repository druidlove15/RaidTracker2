<?php
$rta_style="default";
$rta_step=$rtv_step+1;
include "step$rta_step.php";
include "rti-installmenu.php";
//$incmain="install/rti-install.php";
//$incside="install/rti-installmenu.php";
$_page['title']="RaidTracker: Install step ".($rtv_step+1);
//include "style/$rta_style/settings.php";
?>