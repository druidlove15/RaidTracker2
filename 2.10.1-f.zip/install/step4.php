<?php
$rta_step=4;
if ($rtv_install=='upgrade') {
	include RTS_INSTALL . "/step5.php";
	return;
}
$rta_form=input('server[domain]','hidden',$rtv_server['domain']);
$rta_form.=input('server[path]','hidden',$rtv_server['path']);

if ($rtv_acct['email'] && (!$rtv_char['char'] || !$rtv_char['level'])) {
	$rts_internal['message']="All fields are required, please try again";
	$rtv_acct['email']='';
} else if ($rtv_acct['confirm'] && ($rtv_acct['email']!=$rtv_acct['confirm'])) {
	$rtv_acct['email']='';
	$rts_internal['message']="e-mail did not match.  Please try again";
}
if (!$rtv_acct['email']) {
	$rts_internal['main']="<h1>Create account</h1>\n<p>Now, it's time to create your account.  Please
	enter in your details for your main character.  Once setup is complete, you can create your
	alts under settings.<br />\n
	Please also remember your e-mail address, as this is how you log in to your account.</p>\n";
	$rta_form2.=textfield('acct[email]','e-mail address:',$rtv_acct['email']);
	$rta_form2.=textfield('char[char]','Character:',$rtv_char['char']);
	$rta_form2.=textfield('char[level]','Level:',$rtv_char['level'],'line','1');
	$rta_form2.=rtf_classsel('char[class]',$rtv_char['class']).br();
	$rta_form2.=rtff_role('char[role]',$rtv_char['role'],1).br();
	$rta_form2.=span('&nbsp;','','spaceleft').span(button('Continue'),'','spaceright');
	$rta_form2.=input('install','hidden',$rtv_install);
	$rta_form2.=input('step','hidden','3');
	$rta_form=form(div($rta_form2.$rta_form),'.','post','trueform');
	$rts_internal['main'].=$rta_form;
	return;
} else if (!$rtv_acct['confirm']) {
	$rts_internal['main']="<h1>Confirm account</h1>\n<p>Please confirm your e-mail address, to avoid typos</p>\n";
	foreach ($rtv_acct as $k=>$v) {
		$rta_form.=input ("acct[$k]",'hidden', $v);
	}
	foreach ($rtv_char as $k=>$v) {
		$rta_form.=input ("char[$k]",'hidden', $v);
	}
	$rta_form2.=passfield('acct[confirm]','e-mail address:');
	$rta_form.=input('step','hidden','3');
	$rta_form2.=span('&nbsp;','','spaceleft').span(button('submit'),'','spaceright');
	$rta_form=form(div($rta_form2.$rta_form),'.','post','trueform');
	$rts_internal['main'].=$rta_form;
	return;
} else {
	include "user/db.php";
//	include "include/rti-db.php";
	rtd_openDB($rts_dbserver, $rts_dbuser, $rts_dbpass, $rts_db);
	//--- from rti-settings.php to better usage
	define ('rts_db_acct', "{$rts_dbprefix}account");
	define ('rts_db_char', "{$rts_dbprefix}char");
	unset ($rtv_acct['confirm']);

	$rtv_char['char']=preg_replace("/([\s])/","", $rtv_char['char']);
	$rtv_acct['email']=preg_replace("/([\s])/","", $rtv_acct['email']);
	$rtv_char['char']=ucfirst(strtolower($rtv_char['char']));
	$rtv_acct['main']=$rtv_char['char'];
	$rtv_acct['guildrank']=1;
	$rtv_acct['rtrank']=1;
	$rtv_acct['settings']='c0';
	$rta_temp=rtd_insert(rts_db_acct,$rtv_acct);
	$rta_acctid=rtd_selcol(rts_db_acct,'id',"email='".$rtv_acct['email']."'");
	$rtv_char['account']=$rta_acctid;
//				case 'char':
//	$rtv_char['char']=preg_replace("/([\s])/","", $rtv_char['char']);
//	$rtv_char['char']=ucfirst(strtolower($rtv_char['char']));
	$rta_temp=rtd_insert(rts_db_char, $rtv_char);
	$rta_charid=rtd_selcol(rts_db_char,'id',"`char`='$rtv_char[char]'");
	$rts_internal['main']="<h1>Account created</h1>\n<p>Your account is created.  Now we can proceed to the next step.</p>\n";
	$rta_form.=input('step','hidden','4');
	$rta_form.=input('install','hidden',$rtv_install);
	$rta_form.=span('&nbsp;','','spaceleft').span(button('Continue'),'','spaceright');
	$rta_form=form(div($rta_form),'.','post','trueform');
	$rts_internal['main'].=$rta_form;
}
?>