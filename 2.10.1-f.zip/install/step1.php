<?php
$rta_step=1;
$rtv_step=0;
$rtv_install="install";  //sets up for a new install
$rta_oldRT='0'; //  -- RT_system in keys to find RT version

if (file_exists(_RT_SYS_HOME.'user/rt.php')) {
	include _RT_SYS_INC ."rti-settings.php";
//	include RTS_HOME ."user/db.php";
	//$rta_dbconn=mysql_connect($rts_dbserver,$rts_dbuser,$rts_dbpass,$rts_db);
	//$rta_q="SELECT `value` FROM ".$rts_dbprefix."keys"; // WHERE category='RT_system'";
	//$rta_vercheck=rtd_query($rta_q);
	
	//$rta_vercheck=rtd_selcol("${rts_dbprefix}keys",'value',"`category`='RT_system'");
	//echo "$rta_vercheck - ". RTS_VERSION;
	//if ($rta_vercheck==RTS_VERSION || $rta_vercheck>RTS_VERSION) {
	//	echo "equal or greater";
	//	exit;
	$rts_internal['main']="<h1>RaidTracker Install Error</h1>\n<p>RaidTracker has found another version higher or equal to this version "
   . "has been installed, and the /install "
	. "directory still exists.  Please remove or rename the /install directory to start RaidTracker.</p>\n"
	. "<p>If you continue to have problems, you should remove all files in the /user directory (making sure to back them up first) and then "
	. "reinstall RaidTracker to new database tables.</p>";
	return;
	//} else if ($rta_vercheck!="1.91.1") {
		echo "less"; 
		exit;
	$rts_internal['main']="<h1>RaidTracker Install Error</h1>\n<p>RaidTracker has found another unknown version on your server and "
   . "cannot install.  This may be caused if you are trying to install version ". RTS_VERSION 
	. "over version 1.91 or an earlier/unknown version.  Please remove all files in the /user directory (making sure to back them "
	. "up first) and then try to reinstall RaidTracker again to new database tables.</p>\n"
	. "<p>RaidTracker can be upgraded using current database tables if version 1.91.1 is installed first.  See "
	. "<a href=\"http://raidtracker.fridlunds.org\">the RaidTracker</a> site for details.</p>";
	return;
	//}
	$rtv_install='upgrade';
}
$rts_internal['main']="<h1>Installation</h1>\n<p>Welcome to RaidTracker.  You're about to ".$rta_install." version ".RTS_VERSION.".  ";
$rts_internal['main'].="The next few pages will guide you to get RaidTracker installed easily on your server, and make it ready for your guild "
. "to use.</p><p>Before continuing, please make sure your '/user' folder and any files in this directory are write accessible.  (If you are on "
. "an Apache server, use the command CHMOD 777.)  ";
if ($rta_install='upgrade') $rts_internal['main'].=" Of course, it should be write accessible since this is an upgrade.  You should back up this folder and any database tables prior to the upgrade.";
else $rts_internal['main'].="Please also have your database and server information ready in the next few steps.";
$rts_internal['main'].="</p>\n<p>Ready to continue?</p>\n";
$rta_form=button("button","Next Step");
$rta_form.=input('step','hidden',$rta_step);
$rta_form.=input('install','hidden',$rtv_install);
$rta_form.=input('oldRT','hidden',$rta_oldRT);
$rts_internal['main'].=form(div($rta_form),'.');
?>
