<?php
$rta_classlist=array(
'Dk'=>'Deathknight',
'Dr'=>'Druid',
'Hu'=>'Hunter',
'Ma'=>'Mage',
'Pa'=>'Paladin',
'Pr'=>'Priest',
'Ro'=>'Rogue',
'Sh'=>'Shaman',
'Wl'=>'Warlock',
'Wr'=>'Warrior');

$rta_raidrole=array(
'1'=>'Tank',
'2'=>'Healer',
'3'=>'Melee DPS',
'4'=>'Range DPS');
// testing
$rta_inst=array(
'none'=>'Other',
'aq20'=>'Ahn\'Qiraj (20 man)',
'aq40'=>'Ahn\'Qiraj (40 man)',
'ony'=>'Onyxia\'s Lair',
'bwl'=>'Blackwing Lair',
'zg'=>'Zul\'Gurub',
'mc'=>'Molten Core',
'naxx'=>'Naxxaramas (Classic)',
'gruul'=>'Gruul\'s Lair',
'bt'=>'Black Temple',
'mh'=>'Battle for Mount Hyjal',
'mag'=>'Magtheridon\'s Lair',
'kara'=>'Karazhan',
'sp'=>'Sunwell Plateau',
'za'=>'Zul\'Aman',
'tk'=>'Tempest Keep',
'ssc'=>'Serpentshrine Cavern');
?>