<?php

$rta_mstep[1]="Welcome";
if ($rtv_install=='upgrade') 
	$rta_mstep[]="Verify account";
else
	$rta_mstep[]="Server/DB settings";
$rta_mstep[]='Set up tables';
if ($rtv_install=='install') 
	$rta_mstep[]='Create account';
else 
	$rta_mstep[]='Verifying files';
$rta_mstep[]='RaidTracker Settings';
$rta_mstep[]='Create Terms of Service';
$rta_mstep[]='Finish Install';
$rts_internal['help']="<h1>Installation</h1>\n";
for ($i=1; $i<=count($rta_mstep); $i++) {
	if ($i==$rtv_step+1)
		$rts_internal['help'].="<strong>".$rta_mstep[$i]."</strong>";
	else $rts_internal['help'].=$rta_mstep[$i];
	$rts_internal['help'].="<br />\n";;
}

?>