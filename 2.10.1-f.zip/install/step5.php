<?php
$rta_step=5;
if ($rtv_install=='upgrade') {
	include RTS_HOME . "/user/rt.php";
} else {
	define ('rts_server_offset','0');
	define ('rts_maint','0');
	define ('rts_domain',"$rtv_server[domain]");
	define ('rts_syspath',"$rtv_server[path]");
	define ('rts_guild',"");
	define ('rts_realm',"");
	define ('rts_style',"default");
	define ('rts_levdefault',"");
	define ('rts_chardefault',"");
	define ('rts_sort_time',"false");
	define ('rts_tosv',"false");
}
// -- Introduced 2.1 system user variables
define ("rts_datespan", '30');
define ("rts_days_back", '-1');
define ("rts_days_start", '1');
define ("rts_weeks", '2');
define ("rts_cookie", 'raidtracker');
define ("rts_news", '1');
// -- end 2.1 system settings
$rta_form=input('server[domain]','hidden',rts_domain);
$rta_form.=input('server[syspath]','hidden',rts_syspath);
$rta_form.=input('server[maint]','hidden',rts_maint);
// -- initial settings for RT 2.1.  Introduced 2.1
$rta_form.=input('server[datespan]','hidden','30');
$rta_form.=input('server[days_back]','hidden','-1');
$rta_form.=input('server[days_start]','hidden','1');
$rta_form.=input('server[weeks]','hidden','2');
$rta_form.=input('server[news]','hidden','1');
// -- end 2.1 settings
$rts_internal['main']="<h1>RaidTracker Settings</h1>\n<p>Please enter or check that"
." these settings are correct. Once this is set up, you can change these and other "
." display preferences in the Administration menu.</p>\n";
$rta_time=date("H:i");
$rta_f2=textfield('sct',"Current time:", $rta_time,'line','5','disabled="disabled"');
$rta_f2.=textfield('server[server_offset]',"Offset in hours to realm time:", rts_server_offset);
$rta_f2.=textfield('server[guild]',"Guild Name:",rts_guild);
$rta_f2.=textfield('server[realm]',"Realm and region:",rts_realm);
$rta_f2.="<div>If you have created or installed another style, please enter folder name below.  Otherwise leave it as default.</div>\n";
$rta_f2.=textfield('server[style]',"Style:",rts_style);
$rta_f2.=textfield('server[levdefault]',"Default Level:",rts_levdefault);
$rta_f2.=textfield('server[chardefault]',"Default raiders:",rts_chardefault);
$rta_f2.=group('Sort lists by:','label','','heading spaceleft',"for=\"server[sort_time]\"").
  sel('server[sort_time]',array ('false'=>'Character', 'true'=>'Time created'),rts_sort_time,'','spaceright').br();
//$rta_f2.=group('Separate closure times:','label','','heading spaceleft',"for=\"server[separate_close]\"").
//  sel('server[separate_close]',array ('false'=>'No', 'true'=>'Yes'),'false','','spaceright').br();
//insert game here
$rta_f2.=group('Require TOS?','label','','heading spaceleft',"for=\"server[TOS]\"").
  sel('server[TOS]',array ('false'=>'No', 'true'=>'Yes'),rts_tosv,'','spaceright').br();
$rta_f2.=textfield('server[cookie]','Cookie name:',rts_cookie,'line','10');
$rta_f2.=span('&nbsp;','','spaceleft').span(button('continue'),'','spaceright');
$rta_form.=input('install','hidden',$rtv_install);
$rta_form.=input('step','hidden','5');
$rta_form=form(div($rta_f2.$rta_form),'.','post','trueform');
$rts_internal['main'].=$rta_form.br();
?>