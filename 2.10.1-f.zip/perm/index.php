<?php
$rtv_view='permission';
include "../main/rti-main.php";
?>
