<h1>Instructions</h1>
Permissions are based on RT rankings.  Permissions are granted from the top to the lowest
position chosen for each item.  None means no one gets access, while Everyone applies
to all including logged-out users and visitors.<br />
Self-override can be used on some features where a person can change features even if a person
has too low of a RT rank (such as changing own e-mail addresses.)