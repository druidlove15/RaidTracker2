<?php
//check for rank alter access before continuing
if (!rtf_pcheck('permission_alter')) return;
//get permissions list
$rt_list=rtd_select(rts_db_perm,'*','','ORDER BY `class`, `property`');
//$rt_list=GetRec('SELECT * FROM raid_permission ORDER BY `class`, `property`');

function subform() {
	import_request_variables ("p","rt_");
	global $rt_list, $rt_f, $rt_or;
	foreach ($rt_list as $k=>$v){
		$vartest=$v['property'];
		$varval=$v['value'];
		$varin=$rt_f[$vartest];
		$varor=$rt_or[$vartest];
		if ($varor) $varin=-$varin;
		if ($varval!=$varin) {
			$sql="UPDATE ".rts_db_perm." SET `value`=$varin WHERE `property`='$vartest'";
			mysql_query($sql);
			$rt_list[$k]['value']=$varin;
		}
	}
	echo "<h1>Submitting data</h1>\n<p>Permissions now updated</p>\n";
}


echo "<h1>Permissions</h1>\n";
if ($_POST) subform();
echo '<form method="post" action=".">'."\n";
echo "<table>\n<tr><th>Category</th><th>Name</th><th>Level</th><th>Self<br />Override</th>"
. "<th>Description</th></tr>\n";
foreach ($rt_list as $k) {
	echo "<tr><td>$k[class]</td><td>$k[property]</td><td>";
	switch ($k['property']){
		case 'guildrank_start':
			echo rtff_grank('f['.$k['property']."]", $k['value']);
			break;
		case 'rtrank_start':
		case 'permission_alter':
			echo rtff_rtrank('f['.$k['property']."]", $k['value'],-1);
			break;
		default:
			echo rtff_rtrank('f['.$k['property']."]", $k['value'],0);
	}
	echo "</td><td>";
//	echo "$k[value] ";
	echo '<input type="checkbox" name="or['.$k['property'].']" ';
	if ($k['value']<0) echo 'checked="checked" ';
	echo "/>";
	echo "</td><td>$k[desc]</td></tr>\n";
}
echo "</table>\n";
echo "<input class=\"btn\" type=\"submit\" name=\"submit\" value=\"Submit changes\" />\n";
echo "<br />\n</form>\n";

?>