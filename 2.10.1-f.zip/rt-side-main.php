<h1>About RaidTracker</h1>
<?php
echo rts_guild."'s signup process, used for making raid lists and tracking attendance. More can be seen on <a href=\"$rts_syspath/about/\">about RaidTracker</a>.  Any bugs or features should be addressed to an admin or on the forums.\n";
?>