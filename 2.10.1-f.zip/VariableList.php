<?php
/*********************************************************
 * Variablelist.php
 *********************************************************
 * This is not an an executable file, as everything is in
 * comments.  This is a guide for variables
 *********************************************************

------- Official RT variables
  rt_*     - old variables, functions, etc
 rta_*     - variables local to file
 rtc_*     - cookie variables and functions
 rtd_*     - database functions
 rtf_*     - functions
rtff_*     - form functions (designed to print out form elements.)
 rtg_*     - global variables (please use sparingly)
rthf_*     - HTML functions (deprecated, please use rth_*)
 rth_*     - HTML functions
 rti_*     - file names for ver 2.x compatible modules.
 rto_*     - classes
 rts_*     - static/constant variables (please define them as often as possible)
 rtt_*     - templates, class definitions, etc.
 rtv_*     - variables passed in by $_GET/$_POST

------- other variables
$_page     - array of page elements:

*/
?>