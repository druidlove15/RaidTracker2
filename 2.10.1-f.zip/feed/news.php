<?php
/*******************************************************************************
 * news.php
 * -----------------------------------------------------------------------------
 * Version 2.01 Release 2009-04-30
 * To generate the HTML for the news file
 ******************************************************************************/
//---------------------- Set variables

//---------------------- Functions
function codenl($content) {
// function to convert \n to <br /> and \n\n to <p> blocs
$content=preg_replace('/\n\n/',"</p><p>",$content); //2 ret = new para
$content=preg_replace('/\n/',"<br />",$content); // 1 ret = newline
$content=preg_replace('/(<br \/>|<\/p>)/',"\\1\n",$content); //end tags need newlines at end for readibility
return "<p>$content</p>\n";
}
function codebbc($content) {
	$url="(http[s]?:\/\/[\w\.]+ ";
	$basictag=array(
	'b'=>"<strong>\\3</strong>",
	'i'=>"<em>\\3</em>",
	'u'=>"<span style=\"text-decoration: underline\">\\3</span>",
	'strike'=>"<span style=\"text-decoration: line-through\">\\3</span>",
	's'=>"<span style=\"text-decoration: line-through\">\\3</span>"
	); //defines simple tags
	foreach ($basictag as $k=>$v) {
		$tag[]='/\[('.$k.')=([^\]])\]([^\[]*)\[\/\1\]/';
		$htmltag[]=$v;
	}
	//urls here
	$tag[]='';
	$content=preg_replace($tags, $htmltag, $content);

	return $content;
}
if (!isset($_GET['news'])) $news=10;
else $news=$_GET['news'];
include dirname(__FILE__)."/../user/news.php";
for ($i=0;$i<($news<$rofp_article?$news:$rofp_article);$i++) {
	$newscode.="<div class=\"newsbox\">\n<h1 class=\"news\">"
	.$rofp_news[$i]['headline']."</h1>\n";
if ($pic=$rofp_news[$i]['pic']) {
	$newscode.="<a href=\"$pic\"><img src=\"$pic\" alt=\""
	.$rofp_news[$i]['picalt']."\" width=\"600\" height=\"400\" /></a><br />\n";
}
$article=$rofp_news[$i]['article'];

//echo "$article<br />\n<br />\n";
$article=codenl($article);
//echo "<p>***TEST***</p>\n<p>$article</p><p>***END TEST ***</p>\n";
//exit;
$newscode.=$article."\n";
$rofp_auth=preg_replace('/\([0-9]+\)/','',$rofp_news[$i]['author']);
$newscode.="<div class=\"newspost\">Posted by ".$rofp_auth." on "
. $rofp_news[$i]['createtime']." -- Filed under ".$rofp_news[$i]['category']
. "</div>\n</div>\n";
}
//exit;
echo $newscode;
?>