<?php
echo "<div id=\"main\">\n<div>\n";
include $incmain;
echo "\n</div>\n</div>\n";
