<?php
$top=<<<EOF
<div id="top" style="background: url(/raa/background/random2.jpg)">
<div id="logo">
<img src="/rofptest/rofp2.png" alt="$_page[guild]: Official Guild Site $_page[realm]" />
</div>
<div id="menubar">
<a href="http://www.fridlunds.se/raa/phpbb/viewforum.php?f=4"><img src="/raa/icons/about.png" alt="About" /></a>
<a href="http://forum.rofp.org/"><img src="/raa/icons/forum.png" alt="Forum" /></a>
<a href="http://dkp.rofp.org"><img src="/raa/icons/dkp.png" alt="DKP" /></a>
<a href="http://raid.rofp.org"><img src="/raa/icons/signup.png" alt="RaidTracker" /></a>
<a href="http://forum.rofp.org/viewforum.php?f=5"><img src="/raa/icons/apply.png" alt="Apply" /></a>
</div>
</div>
EOF;
echo "<div id=\"topside\">\n<div>\n$top\n</div>\n</div>\n"
?>