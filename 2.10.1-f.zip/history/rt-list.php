<?php
$currdatestamp=strtotime(date('l Y-m-d H:i:s'));
$rt_charid=rtc_acct();
// ------------------ start with possible add raid
if ($rtv_createbutton) { // to create the raid
	include 'createraid/rt-create2.php';
	return;
} else if ($rtv_create) { //to submit the created raid
	include 'createraid/rt-submit2.php';
}

$currdate=rtf_datetime($currdatestamp,'dt');
$rta_sql_array=array(rts_db_sign.".charid", "raidid", rts_db_char.".class", rts_db_sign.".role", rts_db_sign.".status", "note");
$rta_sql_from=rts_db_sign." INNER JOIN ".rts_db_char ." ON ".rts_db_sign .".char=".rts_db_char.".id";
$rt_sql_basic="SELECT". rts_db_sign.".charid, raidid, ".rts_db_char.".class, ".rts_db_sign.".role, ".rts_db_sign.".status, `note`"
."FROM ".rts_db_sign
."INNER JOIN ".rts_db_char." ON ".rts_db_sign.".char=".rts_db_char.".id";
$result=rtd_select(rts_db_list,'*','',"ORDER BY `date` DESC LIMIT 30",1);
//------------------ breaking news here
$rta_currview="Raid history";
$rta_altview='c';
include "inc2/news.php";
echo "<table id=\"hist\">\n<tr><th style=\"width: 5%\"></th><th>Date</th><th>Instance</th>
<th style=\"width: 5%\">Required</th><th style=\"width: 5%\"><img src=\"".rts_syspath."/images/1.png\" alt=\"Raid List\" /></th>
<th style=\"width: 5%\"><img src=\"".rts_syspath."/images/2.png\" alt=\"Available\" />/<img src=\"".rts_syspath."/images/3.png\" alt=\"Reserve\" /></th>
<th style=\"width: 10%\">Status</th></tr>\n";
$iloop=0;
foreach ($result as $v) {
	echo '<tr><td>';
	$raidtime=strtotime($v['date']);
	$rt_stamp=rtf_datetime($raidtime, 'dt');
	$invite=strtotime($v['inv']);  //$raidtime-$v['invite']*60;
	$cutoff=strtotime($v['freezenew']); //$raidtime-$v['cutoff']*3600;
	$closetime=strtotime($v['endtime']);

	$rt_sql="$rt_sql_basic WHERE charid=$rt_charid AND raidid=$v[id]";
	$rt=rtd_select($rta_sql_from,$rta_sql_array, "charid=$rt_charid AND raidid=$v[id]");
	$rt_a=count(rtd_select($rta_sql_from,$rta_sql_array, "`status` IN ('2', '3', '6', '7') AND raidid=$v[id]",'',1));
	$rt_rl=count(rtd_select($rta_sql_from,$rta_sql_array, "`status`=1 AND raidid=$v[id]",'',1));
	if ($rt){
		echo "<img src=\"".rts_syspath."/images/{$rt['status']}.png\" alt=\"status icon\" />";
		if ($rt['status']==1) echo "<img src=\"".rts_syspath."/images/{$rt['class']}.gif\" alt=\"class icon\" />";
	}
	echo "</td>\n
	<td>$rt_stamp</td>\n<td>";
	if ($v['icon']) echo "<img src=\"".rts_syspath."/images/instance/$v[icon].png\" alt=\"$v[icon]\" />";
	echo "<a href=\"".rts_syspath."/signup/?raidid=$v[id]\" ";
	if ($v['note']) {
		$iloop++;
		echo "id=\"pl$iloop\" rel=\"sc$iloop\">$v[instance]</a>"
		. "<div id=\"sc$iloop\" class=\"rtpopup\">\n"
		."Raid note:<br />$v[note]</div>\n";
	}
	else echo ">$v[instance]</a>";
	echo "</td>\n<td>$v[required]</td><td>$rt_rl</td><td>$rt_a</td>";
	echo "<td>";
	if ($currdatestamp<$cutoff)
		echo "Open";
	else if ($currdatestamp<$invite)
		echo "Closed";
	else if ($currdatestamp<$raidtime)
		echo "Invites started";
	else if ($currdatestamp<$closetime)
		echo "In progress";
	else
		echo "Completed";
	echo "</td></tr>\n";
}
echo "</table>\n";
if (rtf_p('raid_create'))
	echo "<h1>Officers only:</h1>\n"
	."<form method=\"post\" action=\".\"><div>\n"
	."<input type=\"submit\" name=\"createbutton\" value=\"Add a new raid\" />
	</div>\n</form>\n";
?>
<div>Click on the raid above to view the raid list or to sign up/withdraw from a raid.</div>
<script type="text/javascript">
<?php
for ($j=1; $j<=$iloop; $j++)
	echo "dropdowncontent.init(\"pl$j\", \"right-bottom\", 200)\n";
?>
</script>