<?php
$rtv_view='guild';
include "../main/rti-main.php";
?>
