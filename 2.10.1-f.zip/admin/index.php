<?php
$rtv_view='admin';
include "../main/rti-main.php";
?>
