<?php 
/*************************************************
 * rti-maint.php
 *************************************************
 * Version 2.0 maintenance check
 *************************************************/
if ($rts_view=='login' || rtc_priv==1) return;
$rts_internal['main']="<h1>RaidTracker Maintenance</h1>
<p>The site is currently undergoing maintenance and is unavailable at the moment.  This may take a few minutes.  We are working to improve RaidTracker.  In the meantime, please use the forums to post any changes to your subscriptions, and an administrator will take care of it as soon as possible.</p>"
?>