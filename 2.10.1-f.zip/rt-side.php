<?php
$rta_menu="<div id=\"rtmenu\">\n<div id=\"rtmenuhead\">RaidTracker menu:</div>\n";
?>
<h1>Menu</h1>
<?php
if (!$rts_syspath) $rts_syspath="/rtest";
if ($maintenance) echo "<h2>Maintainance mode</h2>\n";
if (function_exists('rt_GetAcct')){
	$rta_mainid=rtf_acctmain(rt_GetAcct());
	$rta_rank=rt_GetRank();
	$rta_main=rt_GetName();
} else if (function_exists('rtc_id')) {
	$rta_mainid=rtc_id();
	$rta_rank=rtc_priv();
	$rta_main=rtc_name();
}
if ($rta_mainid){
	echo url("$rts_syspath/login","Logout") ." ";//.rtf_char($rta_mainid).br();
	if (!$maintenance || $rta_rank==1) {
		echo rtf_char($rta_mainid).br();
		if ($rt_menu!='char') echo url("$rts_syspath/character","Settings").br();
		echo url("$rts_syspath/history/","Raid history").br();
		echo url("$rts_syspath/calendar/","Raid calendar").br();
		if ($rt_menu!='guild')
			echo url("$rts_syspath/guild","Guild list").br();
		if (rtf_p('admin_view')&& $rt_menu !='admin')
			echo url("$rts_syspath/admin","Administration mode").br();
	} else {
		echo $rta_main.br();
		echo "Options unavailable during maintenance.".br();
	}
} else {
	$rt_url="$rts_syspath/login/".($maintenance?"?special=1":"");
	echo url("$rts_syspath/login","Log in/create account").br();
}
?>