<?php
/*******************************************************************************
 * adminsettings.php
 * -----------------------------------------------------------------------------
 * Version 2.00: Change settings
 ******************************************************************************/
//---- 
if (!$rtv_formdata['sys']) {
	$rtv_formdata['sys']['server_offset']=rts_server_offset;
	$rtv_formdata['sys']['style']=rts_style;
	$rtv_formdata['sys']['guild']=rts_guild;
	$rtv_formdata['sys']['realm']=rts_realm;
	$rtv_formdata['sys']['levdefault']=rts_levdefault;
	$rtv_formdata['sys']['maint']=rts_maint;
	$rtv_formdata['sys']['domain']=rts_domain;
	$rtv_formdata['sys']['syspath']=rts_syspath;
	$rtv_formdata['sys']['sort_time']=rts_sort_time;
	$rtv_formdata['sys']['TOS']=rts_TOS;
	$rtv_formdata['sys']['tosv']=rts_tosv;
	$rtv_formdata['sys']['datespan']=rts_datespan;
	$rtv_formdata['sys']['days_back']=rts_days_back;
	$rtv_formdata['sys']['days_start']=rts_days_start;
//	$rtv_formdata['sys']['days_reset']=rts_days_reset;  //reset days
	$rtv_formdata['sys']['weeks']=rts_weeks;
	$rtv_formdata['sys']['cookie']=rts_cookie;
	$rtv_formdata['sys']['news']=rts_news;
	
} else {
	$rts_internal['main'].="<h1>System Settings</h1>\n<p>Settings have been saved."
	. "To see your settings live, click here to ".url('.','refresh');
	return;
}
$rta_form="<h1>System Settings</h1>\n";
$rta_form2=textfield('formdata[sys][server_offset]','Server offset',$rtv_formdata['sys']['server_offset'],'line','1')
.textfield('formdata[sys][style]','RaidTracker Style',$rtv_formdata['sys']['style'],'line','10')
.textfield('formdata[sys][guild]','Guild name',$rtv_formdata['sys']['guild'])
.textfield('formdata[sys][realm]','Realm name',$rtv_formdata['sys']['realm'])
.textfield('formdata[sys][levdefault]','Default Level',$rtv_formdata['sys']['levdefault'],'line','1')
.select ('formdata[sys][maint]','Maintenance mode:',
  array(0=>'Off',1=>'On'),$rtv_formdata['sys']['maint']).br()
//.textfield('formdata[sys][maint]','Maintenance Mode*',$rtv_formdata['sys']['maint'],'line','1')
.textfield('formdata[sys][domain]','Domain name',$rtv_formdata['sys']['domain'])
.textfield('formdata[sys][syspath]','Path to RaidTracker',$rtv_formdata['sys']['syspath'])
.select ('formdata[sys][sort_time]','Sort lists by:',
  array(0=>'Class and Name',1=>'Time'),$rtv_formdata['sys']['sort_time']).br()
//.textfield('formdata[sys][sort_time]','Sort by Time',$rtv_formdata['sys']['sort_time'],'line','1')
.textfield('formdata[sys][TOS]','Require TOS?',$rtv_formdata['sys']['TOS'],'line','1')
.textfield('formdata[sys][tosv]','TOS Version',$rtv_formdata['sys']['tosv'],'line','1')
.select ('formdata[sys][datespan]','Default days tracking:',
  array(7=>'7',14=>'14',30=>'30',60=>'60',90=>'90',-1=>'Life'),$rtv_formdata['sys']['datespan']).br()
//.textfield('formdata[sys][datespan]','Stats tracking (days):',$rtv_formdata['sys']['datespan'],'line','1')
.select ('formdata[sys][days_back]','Days back in calendar:',
  array(6=>'6',5=>'5',4=>'4',3=>'3',2=>'2',1=>'1',0=>'none',-1=>'Use fixed day'),$rtv_formdata['sys']['days_back']).br()
//.textfield('formdata[sys][days_back]','Days back in calendar:',$rtv_formdata['sys']['days_back'],'line','1')
.select ('formdata[sys][days_start]','Calendar starts on:',
  array(0=>'Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'),$rtv_formdata['sys']['days_start']).br()
//.textfield('formdata[sys][days_start]','Calendar starts on:',$rtv_formdata['sys']['days_start'],'line','1')

//.textfield('formdata[sys][days_reset]','Days back in calendar:',$rtv_formdata['sys']['days_back'],'line','1') //reset day
.select ('formdata[sys][weeks]','Number of Weeks:',array(1=>'1','2','3','4'),$rtv_formdata['sys']['weeks']).br()
//.textfield('formdata[sys][weeks]','Number of weeks:',$rtv_formdata['sys']['weeks'],'line','1')
.textfield('formdata[sys][cookie]','Cookie name:',$rtv_formdata['sys']['cookie'],'line','10')
.select ('formdata[sys][news]','Show news:',
  array(2=>'On all views',1=>'Main view only',0=>'Always hide'),$rtv_formdata['sys']['news']).br()

//.textfield('formdata[sys][news]','News format:',$rtv_formdata['sys']['news'],'line','1')
.button('formdata[submit]','Submit');
$rta_form2.=input('formview','hidden','adminsettings');

$rta_form.=form($rta_form2,'.','post','','trueform');
$rts_internal['main'].=$rta_form;
$rts_internal['help'].="<h1>Adjusting settings</h1>"
.bold("Server Offset")."-Use this to adjust the difference between server time "
."Game server time".br()
.bold("RaidTracker Style")."-The default style for all of RT".br()
.bold("Maintenance Mode")."-Maintenance mode disables RT to all except superadmins. "
."Recommended to turn off except when debugging.".br()
.bold("Sort by")."-Sorting order only in list view.  Sorting only occurs within each "
."role group (i.e. healers)".br()
.bold("TOS required / version")."-If you require users to read a Term of Use page before starting, "
."set required to 1, and version to any number.  Changing a version number will "
."cause everyone to be prompted with the TOS screen again before continuing. ".br()
.bold("Default Days Tracking")."- How many days do you want to track as default in Guild "
."and Settings view.  Life means all stats.  You can change this temporary in each view. ".br()
.bold("Days back")."-If set to anything other than 'Use Fixed Day', calendar will "
."always show these many days prior to today as the start.".br()
.bold("Calendar starts on")."-Ignored unless if 'Days back in Calendar' is set to 'Use Fixed Day' ".br()
.bold("Number of weeks")."-This will show the number of 7-day weeks in the calendar "
." from the first day.".br()
.bold("Cookie name")."-Changing this will log out other users.  But change this "
."if you have more than one copy of RT installed on the same server.".br()
;
?>