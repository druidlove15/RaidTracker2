<?php
$rtv_view='log';
include "../main/rti-main.php";
?>
