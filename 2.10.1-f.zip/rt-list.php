<?php
$currdatestamp=strtotime(date('l Y-m-d H:i:s'));
$rt_charid=rt_GetAcct();
if (!$rts_syspath) $rts_syspath="/rtest";

$currdate=rtf_datetime($currdatestamp,'dt');

$rt_sql_basic=<<<SQLQ
SELECT
raid_sign.charid, raidid, raid_char.class, raid_sign.role, raid_sign.status, `note`
FROM raid_sign
INNER JOIN raid_char ON raid_sign.char=raid_char.id
SQLQ;
//$result=GetRec("SELECT * FROM raid_list WHERE `date`> NOW()- INTERVAL 23 HOUR ORDER BY `date` ASC");
//else
$result=GetRec("SELECT * FROM raid_list ORDER BY `date` DESC LIMIT 30");
//------------------ breaking news here
$rt_newshead=GetRec("SELECT `name` FROM raid_keys WHERE category='news_head'");
$rt_newshead=$rt_newshead[1]['name'];
$rt_news=GetRec("SELECT `name` FROM raid_keys WHERE category='news'");
$rt_news=$rt_news[1]['name'];
if ($rt_newshead && $rt_news)
echo "<div class=\"rt news\">\n<h1>$rt_newshead</h1>\n$rt_news</div>\n";


echo "<h1>Raid list</h1>\n";
echo "Current time is:  $currdate<br />\n";
echo '<span class="rt heading">New</span> Try out the new <a href="/rtracker/calendar/">Calendar view</a>.<br />'."\n";
echo "<form method=\"post\" action=\".\">\n";
echo "<table id=\"hist\">\n<tr><th style=\"width: 5%\"></th><th>Date</th><th>Instance</th>
<th style=\"width: 5%\">Required</th><th style=\"width: 5%\"><img src=\"$rts_syspath/images/1.png\" alt=\"Raid List\" /></th>
<th style=\"width: 5%\"><img src=\"$rts_syspath/images/2.png\" alt=\"Available\" />/<img src=\"$rts_syspath/images/3.png\" alt=\"Reserve\" /></th>
<th style=\"width: 10%\">Status</th></tr>\n";
$iloop=0;
foreach ($result as $v) {
	echo '<tr><td>';
	$raidtime=strtotime($v['date']);
	$rt_stamp=rtf_datetime($raidtime, 'dt');
	$invite=$raidtime-$v['invite']*60;
	$cutoff=$raidtime-$v['cutoff']*3600;
	$closetime=strtotime($v['endtime']);
	$rt_sql="$rt_sql_basic WHERE charid=$rt_charid AND raidid=$v[id]";
	$rt=GetRec($rt_sql);
	$rt_a=count(GetRec("$rt_sql_basic WHERE `status` IN ('2', '3', '6', '7') AND raidid=$v[id]"));
	$rt_rl=count(GetRec("$rt_sql_basic WHERE raidid=$v[id] AND `status`=1"));
	if ($rt){
		echo "<img src=\"$rts_syspath/images/{$rt[1]['status']}.png\" alt=\"status icon\" />";
		if ($rt[1]['status']==1) echo "<img src=\"$rts_syspath/images/{$rt[1]['class']}.gif\" alt=\"class icon\" />";
	}
	echo "</td>\n
	<td>$rt_stamp</td>\n<td>";
	if ($v['icon']) echo "<img src=\"$rts_syspath/images/instance/$v[icon].gif\" alt=\"$v[icon]\" />";
	echo "<a href=\"$rts_syspath/signup/?raidid=$v[id]\" ";
	if ($v['note']) {
		$iloop++;
		echo "id=\"pl$iloop\" rel=\"sc$iloop\">$v[instance]</a>"
		. "<div id=\"sc$iloop\" class=\"rtpopup\">\n"
		."Raid note:<br />$v[note]</div>\n";
	}
	else echo ">$v[instance]</a>";
	echo "</td>\n<td>$v[required]</td><td>$rt_rl</td><td>$rt_a</td>";
	echo "<td>";
	if ($currdatestamp<$cutoff)
		echo "Open";
	else if ($currdatestamp<$invite)
		echo "Frozen";
	else if ($currdatestamp<$raidtime)
		echo "Invites started";
	else if ($currdatestamp<$closetime)
		echo "In progress";
	else
		echo "Closed";
	echo "</td></tr>\n";
}
echo "</table>\n";
if (rtf_p('raid_create'))
//if (rt_Permissions(3)) {
	echo "<a href=\"$rts_syspath/createraid\">Create a new raid</a><br />\n";
//}
?>
</form>
<div>Click on the raid above to view the raid list or to sign up/withdraw from a raid.</div>
<script type="text/javascript">
<?php
for ($j=1; $j<=$iloop; $j++)
	echo "dropdowncontent.init(\"pl$j\", \"right-bottom\", 200)\n";
?>
</script>