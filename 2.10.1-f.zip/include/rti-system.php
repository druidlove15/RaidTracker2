<?php
/******************************************
 * rti-system.php
 ******************************************
 * Used for version tracking
 ******************************************/
$rts_version='2.10';
$rts_cookiev='190';
define ('RTS_VERSION',"$rts_version");
define ('RTS_COOKIE',"$rts_cookiev");
?>