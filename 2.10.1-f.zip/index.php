<?php
/*
$rt=true;
$frames=0;
*/
$rt_menu='main';
$incmain='rt-list.php';
//$incside='rt-side-main.php';
$title='Raid list';
include_once "./main/rti-main.php";
?>