<?php
$rtv_view='rank';
include "../main/rti-main.php";
?>
