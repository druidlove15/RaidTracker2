<?php
//check for rank alter access before continuing
if (!rtf_pcheck('rank_alter')) return;

function subform() {
	import_request_variables ("p","rt_");
	global $rt_rtsubmit, $rt_rt, $rt_rt_name, $rt_guildsubmit;
	if ($rt_rtsubmit) $cat="rt";
	else $cat="guild";
	if ($rt_rtsubmit=="Delete"||$rt_guildsubmit=="Delete")
		$sql="DELETE FROM ".rts_db_keys." WHERE category='$cat' AND `name`='$rt_rt'";
	else if ($rt_rt=="new")
		$sql="INSERT INTO ".rts_db_keys." SET category='$cat', `name`='$rt_rt_name[$rt_rt]'";
	else
		$sql="UPDATE ".rts_db_keys." SET `name`='$rt_rt_name[$rt_rt]' WHERE category='$cat' AND `name`='$rt_rt'";
	mysql_query($sql);
}


function rt_ranksql($text) {
	$sql="SELECT `name` from ".rts_db_keys." WHERE category='$text' ORDER BY id ASC";
	$result=rtd_select (rts_db_keys,array('name'),"category='$text'","ORDER BY id ASC",1);
//	$result=GetRec($sql);
	for ($i=0; $i<count($result); $i++)
		$r[$i]=$result[$i]['name'];
	return $r;
}
echo "<h1>Ranks</h1>\n";
if ($_POST) subform();
$rt_rtr=rt_ranksql("rt");
echo "<h2>RaidTracker Ranks</h2>\n";
echo '<form method="post" action=".">'."\n";
foreach ($rt_rtr as $k) {
	echo "<input type=\"radio\" name=\"rt\" value=\"$k\" />
		<input type=\"text\" name=\"rt_name[$k]\" value=\"$k\" /><br />\n";
}
if (count($rt_rtr)<10)
echo "<input type=\"radio\" name=\"rt\" value=\"new\" />
	<input type=\"text\" name=\"rt_name[new]\" value=\"(new rank)\" /><br />\n";
echo "<input type=\"submit\" name=\"rtsubmit\" value=\"Submit\" />\n";
if (count($rt_rtr)>1)
echo "<input type=\"submit\" name=\"rtsubmit\" value=\"Delete\" />\n";
echo "<br />\n</form>\n";
$rt_g=rt_ranksql("guild");
echo "<h2>Guild Ranks</h2>\n";
echo '<form method="post" action=".">'."\n";
foreach ($rt_g as $k) {
	echo "<input type=\"radio\" name=\"rt\" value=\"$k\" />
		<input type=\"text\" name=\"rt_name[$k]\" value=\"$k\" /><br />\n";
}
if (count($rt_g)<10)
echo "<input type=\"radio\" name=\"rt\" value=\"new\" />
	<input type=\"text\" name=\"rt_name[new]\" value=\"(new rank)\" /><br />\n";
echo "<input type=\"submit\" name=\"guildsubmit\" value=\"Submit\" />\n";
if (count($rt_g)>1)
echo "<input type=\"submit\" name=\"guildsubmit\" value=\"Delete\" />\n";
echo "<br />\n</form>\n";

?>