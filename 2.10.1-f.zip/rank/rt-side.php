<h1>Instructions</h1>
<h2>Edit a rank</h2>
Select the radio button next to the rank name, enter a new name, and click "Submit"<br />
<h2>Add a rank</h2>
Select the radio button next to "(new rank)", enter a name, and click "Submit"<br />
<h2>Delete a rank</h2>
Select the radio button next to the rank, and click "Delete"<br />