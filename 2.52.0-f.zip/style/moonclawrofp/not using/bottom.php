<?php
$content="RaidTracker version $rts_version. &copy;2007-2008 Frank Fridlund (Martie, Quel'Thalas EU). "
.url("http://raidtracker.rofp.org",'About RaidTracker');
echo "<div id=\"bottomside\">\n<div>\n$content\n</div>\n</div>\n";
echo "</body>\n</html>\n";
