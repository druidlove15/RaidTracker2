<?php
$top=<<<EOF
<div id="logo"><img src="$_page[logo]" alt="RaidTracker" /></div>
EOF;
echo "<div id=\"topside\">\n$top\n</div>\n"
?>