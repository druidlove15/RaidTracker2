<?php
$rt_menu='main';
$incmain='rt-list.php';
$title='Raid list';
include_once "./main/rti-main.php";
?>