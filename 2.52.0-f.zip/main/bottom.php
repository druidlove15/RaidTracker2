<?php
$content="RaidTracker version $rts_version. &copy;2007-2010 Frank Spychaj-Fridlund (Martie, Quel'Thalas EU). "
.url("http://raidtracker.fridlunds.org",'About RaidTracker');
echo "<div id=\"bottomside\">\n<div>\n$content\n</div>\n</div>\n";
echo "</body>\n</html>\n";
